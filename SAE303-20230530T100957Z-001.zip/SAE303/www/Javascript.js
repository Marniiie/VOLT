// function myFunction() {
//     var element = document.body;
//     element.classList.toggle("dark-mode");
//  }


/* Calcul de votre progression sur la page
   et modification de la longueur de la scroll bar */
   function scroll_bar() {
    'use strict';
    var t = document.querySelector('#scroll-bar'),
        a = document.body.clientHeight,
        n = window.innerHeight,
        g = window.pageYOffset,
        o = g / (a - n) * 100;

    t.style.width = o + '%';
}

// Appel de la fonction lorsque la page est chargée
window.addEventListener('load', scroll_bar);

/* Appel de la fonction lors d'un mouvement sur la page
   (scroll, mollette de la souris, flèches de direction, etc.) */
window.addEventListener('scroll', scroll_bar);



new Chartist.Line('#chart2', {
    labels: ['', '1970', '1980', '1990', '2000', '2010'],
    series: [
      [7, 10, 13, 14, 16, 18],
      [7, 7, 8, 10, 10, 17],
      [3, 4, 6, 8, 10, 13],
      [1, 1, 2, 3, 4, 5],
      [1, 1, 2, 3, 4, 4],
      [0, 0, 0, 0, 0, 2],
      
    ]
  }, {
    fullWidth: true,
    chartPadding: {
      right: 40
    }
  });
  

  new Chartist.Line('#chart1', {
    labels: [1800, 1850, 1900, 1950, 2000, 2020],
    series: [
      [1, , , 2, 3, 6, 7],
    ]
  }, {
    high: 9,
    low: 0,
    showArea: true,
    showLine: true,
    showPoint: false,
    fullWidth: true,
    axisX: {
      showLabel: true,
      showGrid: false
    }
  });


  // fetch('./svg/graphchrono.svg')
  // .then(res => res.text())
  // .then(svg => {
  //     let draw = SVG().addTo('#graphsvg').size('256', '256');
  //     draw.svg(svg);
  //     draw.size('256', '256');
  //     draw.attr("preserveAspectRatio", "xMinYMin meet");
  //     draw.viewbox(0, 0, draw.attr("width"), draw.attr("height"));
  //     draw.attr("width", null).attr("height" , null);

  //     const barre = draw.findOne('#barre');


  //     const graphique = draw.findOne('#graphique');

  //     //  var survol = function() {
  //     //       tic1.scale(1000).animate({duration: 300, delay: 4000, when: 'now', swing: true, times: 5,}).scale(0.001)
  //     //       console.log('coucou')
  //     //   }
  //     //   tic1.on('mouseover', survol)
  // });